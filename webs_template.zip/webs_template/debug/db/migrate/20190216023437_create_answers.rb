class CreateAnswers < ActiveRecord::Migration
  def change
  end
end
