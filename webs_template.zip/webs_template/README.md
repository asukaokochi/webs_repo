Life is Tech ! School Webサービスプログラミングコースの教材で利用するテンプレートです。
